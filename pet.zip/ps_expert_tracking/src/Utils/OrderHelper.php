<?php

declare(strict_types=1);

namespace PsExpertTracking\Utils;

use Order;
use Validate;

class OrderHelper
{
    public function isValidOrder($order): bool
    {
        return Validate::isLoadedObject($order);
    }

    public function getClientIdForServerSide(Order $order): string
    {
        // Próbujemy pobrać ciastko, jeśli skrypt działa w sesji użytkownika
        if (isset($_COOKIE['_ga'])) {
            return preg_replace('/^GA\d\.\d\./', '', $_COOKIE['_ga']);
        }
        // Fallback: Generujemy ID na podstawie klienta, żeby było stałe
        return '555.' . (string)$order->id_customer . '.' . (string)$order->date_add; 
    }
}