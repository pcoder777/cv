<?php

declare(strict_types=1);

namespace PsExpertTracking\Service;

use Db;
use Context;
use PrestaShopLogger;

class SessionManager
{
    private $tableName;

    // ID kontenera (Suffix) wzięty z Twojego GoogleClient.php (G-LM6KRYGMJ3)
    // To kluczowe, aby pobrać właściwą sesję, a nie np. sesję z testowego sklepu
    private const GA_CONTAINER_SUFFIX = 'LM6KRYGMJ3'; 

    public function __construct()
    {
        $this->tableName = _DB_PREFIX_ . 'expert_sessions';
    }

    public function saveSession(int $cartId): void
    {
        if (!$cartId) {
            return;
        }

        $context = Context::getContext();
        // Pobieramy ciastka bezpośrednio z superglobalnej dla pewności
        $cookies = $_COOKIE;

        // 1. Pobieramy GA Client ID (Ulepszona metoda Regex)
        // Wyciąga ID klienta nawet jeśli format ciastka się zmieni (GA1.1 lub GA1.2)
        $clientId = null;
        if (isset($cookies['_ga']) && preg_match('/GA\d\.\d\.(\d+\.\d+)/', (string)$cookies['_ga'], $matches)) {
            $clientId = $matches[1];
        }

        // 2. Pobieramy GA Session ID dla KONKRETNEGO kontenera
        // Szukamy ciasteczka o nazwie _ga_LM6KRYGMJ3
        $sessionId = null;
        $targetCookieName = '_ga_' . self::GA_CONTAINER_SUFFIX;

        if (isset($cookies[$targetCookieName])) {
            $parts = explode('.', (string)$cookies[$targetCookieName]);
            // Format ciastka to zazwyczaj: GS1.1.SESSION_ID.1.1...
            // Interesuje nas trzeci element (indeks 2)
            if (isset($parts[2])) {
                $sessionId = $parts[2];
            }
        }
        
        // Fallback: Jeśli nie znaleziono dedykowanego ciasteczka (rzadkie przypadki),
        // szukamy w pętli, ale to rozwiązanie awaryjne
        if (!$sessionId && !empty($cookies)) {
            foreach ($cookies as $key => $value) {
                if (strpos((string)$key, '_ga_') === 0) {
                    $parts = explode('.', (string)$value);
                    if (isset($parts[2])) {
                        $sessionId = $parts[2];
                        break; // Bierzemy pierwsze znalezione (ryzykowne, ale lepsze niż nic)
                    }
                }
            }
        }

        // 3. Pobieramy GCLID (Priorytet: Cookie Context -> $_COOKIE -> $_GET)
        $gclid = null;
        if (isset($context->cookie->expert_gclid)) {
            $gclid = $context->cookie->expert_gclid;
        } elseif (isset($cookies['expert_gclid'])) {
            $gclid = $cookies['expert_gclid'];
        }

        // --- FILTR JAKOŚCI DANYCH ---
        // Jeśli nie mamy identyfikatorów, nie zapisujemy, bo dane są bezużyteczne dla API Google.
        // Zapobiega to puchnięciu bazy danych o wpisy botów i osób bez zgody na cookies.
        if (!$clientId && !$gclid && !$sessionId) {
            return;
        }

        // 4. Budowanie zapytania (Zabezpieczone pSQL)
        $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'], 0, 250) : '';
        
        $sqlCartId = (int)$cartId;
        $sqlClientId = $clientId ? "'" . pSQL($clientId) . "'" : "NULL";
        $sqlSessionId = $sessionId ? "'" . pSQL($sessionId) . "'" : "NULL";
        $sqlGclid = $gclid ? "'" . pSQL($gclid) . "'" : "NULL";
        $sqlUserAgent = "'" . pSQL($userAgent) . "'";

        // Używamy ON DUPLICATE KEY UPDATE, aby zawsze mieć najświeższe dane dla koszyka
        $sql = "INSERT INTO `{$this->tableName}` (id_cart, ga_client_id, ga_session_id, gclid, user_agent, date_add)
                VALUES ($sqlCartId, $sqlClientId, $sqlSessionId, $sqlGclid, $sqlUserAgent, NOW())
                ON DUPLICATE KEY UPDATE 
                ga_client_id = VALUES(ga_client_id),
                ga_session_id = VALUES(ga_session_id),
                gclid = VALUES(gclid),
                date_add = NOW()";

        try {
            Db::getInstance()->execute($sql);
        } catch (\Throwable $e) {
            // Logujemy błąd bazy, ale nie przerywamy działania sklepu
            PrestaShopLogger::addLog("PsExpert: DB Error saving session for Cart $cartId: " . $e->getMessage(), 3);
        }
    }

    public function getSessionData(int $cartId): ?array
    {
        $sql = 'SELECT * FROM `' . $this->tableName . '` WHERE id_cart = ' . (int)$cartId;
        $row = Db::getInstance()->getRow($sql);
        
        return $row ?: null;
    }
}