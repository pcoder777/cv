<?php

declare(strict_types=1);

namespace PsExpertTracking\Service;

use Context;
use Order;
use Product;
use Cart;

class DataLayerGenerator
{
    private $hasher;

    public function __construct(UserHasher $hasher)
    {
        $this->hasher = $hasher;
    }

    public function getGlobalConfig(): array
    {
        $context = Context::getContext();
        $user = [];
        
        if ($context->customer && $context->customer->isLogged()) {
            $user = [
                'email_hash' => $this->hasher->hashUserData($context->customer->email),
                'id' => (string)$context->customer->id
            ];
        }

        return [
            'event' => 'ps_expert_init',
            'user_data' => $user,
            'currency' => $context->currency ? $context->currency->iso_code : 'PLN'
        ];
    }

    // --- NOWE METODY DLA E-COMMERCE ---

    public function getViewItemEvent(Product $product, $id_product_attribute = 0): array
    {
        return [
            'event' => 'view_item',
            'ecommerce' => [
                'currency' => Context::getContext()->currency->iso_code,
                'value' => (float)$product->getPrice(true, $id_product_attribute),
                'items' => [
                    $this->formatProductItem($product, $id_product_attribute)
                ]
            ]
        ];
    }

    public function getBeginCheckoutEvent(Cart $cart): array
    {
        $items = [];
        foreach ($cart->getProducts() as $product) {
            $items[] = [
                'item_id' => (string)$product['id_product'],
                'item_name' => $product['name'],
                'price' => (float)$product['price_wt'],
                'quantity' => (int)$product['cart_quantity']
            ];
        }

        return [
            'event' => 'begin_checkout',
            'ecommerce' => [
                'currency' => Context::getContext()->currency->iso_code,
                'value' => (float)$cart->getOrderTotal(true),
                'items' => $items
            ]
        ];
    }

    // Helper do formatowania pojedynczego produktu
    public function formatProductItem(Product $product, $id_product_attribute = 0): array
    {
        // Pobieramy kategorie domyslna
        $categoryName = '';
        if ($category = new \Category((int)$product->id_category_default, Context::getContext()->language->id)) {
            $categoryName = $category->name;
        }

        return [
            'item_id' => (string)$product->id,
            'item_name' => $product->name,
            'item_category' => $categoryName,
            'price' => (float)$product->getPrice(true, $id_product_attribute),
            'quantity' => 1
        ];
    }

    public function getPurchaseEvent(Order $order): array
    {
        $products = $order->getProducts();
        $items = [];

        foreach ($products as $product) {
            $items[] = [
                'item_id' => (string)$product['product_id'],
                'item_name' => $product['product_name'],
                'price' => (float)$product['product_price_wt'],
                'quantity' => (int)$product['product_quantity']
            ];
        }

        $customer = $order->getCustomer();

        return [
            'event' => 'purchase',
            'ecommerce' => [
                'transaction_id' => (string)$order->id,
                'value' => (float)$order->total_paid,
                'tax' => (float)($order->total_paid - $order->total_paid_tax_excl),
                'shipping' => (float)$order->total_shipping,
                'currency' => 'PLN',
                'items' => $items
            ],
            'user_data' => [
                'email' => $customer->email,
                'sha256_email_address' => $this->hasher->hashUserData($customer->email)
            ]
        ];
    }
}