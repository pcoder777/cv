<?php

declare(strict_types=1);

namespace PsExpertTracking\Hook;

use PsExpertTracking\Service\DataLayerGenerator;
use Module;
use Order;
use Context;
use Product;
use Tools;

class FrontHook
{
    private $generator;

    public function __construct(DataLayerGenerator $generator)
    {
        $this->generator = $generator;
    }

    public function executeHeader(array $params, Module $module): string
    {
        $context = Context::getContext();
        $controller = $context->controller;
        $smartyVars = [];

        // 1. Global Init
        $smartyVars['ps_expert_global'] = json_encode($this->generator->getGlobalConfig());

        // 2. Event: view_item (Tylko na stronie produktu)
        if ($controller instanceof \ProductController) {
            // Pobieramy ID produktu z URL
            $id_product = (int)Tools::getValue('id_product');
            if ($id_product) {
                $product = new Product($id_product, true, $context->language->id);
                // Dla wariantów (id_product_attribute) pobieramy domyślny lub wybrany
                $id_product_attribute = (int)Tools::getValue('id_product_attribute', $product->cache_default_attribute);
                
                $viewItemEvent = $this->generator->getViewItemEvent($product, $id_product_attribute);
                $smartyVars['ps_expert_view_item'] = json_encode($viewItemEvent);
            }
        }

        // 3. Event: begin_checkout (Strona zamówienia)
        // Wykrywamy czy to kontroler 'order' (krok 1 checkoutu)
        if ($controller instanceof \OrderController && !isset($params['order'])) {
             // Upewniamy się, że koszyk nie jest pusty
             if ($context->cart && $context->cart->nbProducts() > 0) {
                 $beginCheckoutEvent = $this->generator->getBeginCheckoutEvent($context->cart);
                 $smartyVars['ps_expert_begin_checkout'] = json_encode($beginCheckoutEvent);
             }
        }

        $context->smarty->assign($smartyVars);

        return $module->display($module->getLocalPath(), 'views/templates/hook/header.tpl');
    }

    public function executeOrderConfirmation(array $params, Module $module): string
    {
        if (isset($params['order']) && $params['order'] instanceof Order) {
            $order = $params['order'];
        } elseif (isset($params['objOrder']) && $params['objOrder'] instanceof Order) {
            $order = $params['objOrder'];
        } else {
            return '';
        }

        $purchaseEvent = $this->generator->getPurchaseEvent($order);

        Context::getContext()->smarty->assign([
            'ps_expert_purchase' => json_encode($purchaseEvent),
        ]);

        return $module->display($module->getLocalPath(), 'views/templates/hook/order_confirmation.tpl');
    }
}