<?php

declare(strict_types=1);

namespace PsExpertTracking\Hook;

use Configuration;
use Order;
use Customer;
use Address;
use Country;
use Currency;
use PsExpertTracking\Service\GoogleClient;
use PsExpertTracking\Service\UserHasher;
use PsExpertTracking\Service\SessionManager;
use PsExpertTracking\Utils\OrderHelper;

class OrderStatusHook
{
    private $client;
    private $hasher;
    private $helper;
    private $sessionManager;

    public function __construct($client, $hasher, $helper, $sessionManager)
    {
        $this->client = $client;
        $this->hasher = $hasher;
        $this->helper = $helper;
        $this->sessionManager = $sessionManager;
    }

    public function execute(array $params): void
    {
        // 1. Walidacja podstawowa
        if (!isset($params['newOrderStatus'], $params['id_order'])) {
            return;
        }

        $newStatusId = (int)$params['newOrderStatus']->id;
        $orderId = (int)$params['id_order'];

        // A. Statusy generujące ZAKUP (Purchase)
        $purchaseStatuses = [
            (int)Configuration::get('PS_OS_PAYMENT'), // 2
            12, 34, 35, // Statusy bramek płatności (P24, PayU, COD)
            3,  // Processing
            21, // Shipped
            10, // Bank wire
        ];
        
        // B. Statusy generujące ZWROT (Refund)
        $refundStatuses = [
            (int)Configuration::get('PS_OS_REFUND'),   // 7
            (int)Configuration::get('PS_OS_CANCELED'), // 6
        ];
        
        $isPaidStatus = $params['newOrderStatus']->paid == 1;

        // Decyzja: Co robimy?
        $eventName = '';
        if (in_array($newStatusId, $purchaseStatuses) || $isPaidStatus) {
            $eventName = 'purchase';
        } elseif (in_array($newStatusId, $refundStatuses)) {
            $eventName = 'refund';
        } else {
            return;
        }

        $order = new Order($orderId);
        if (!$this->helper->isValidOrder($order)) {
            return;
        }

        // 2. Pobieranie sesji (W bloku Try-Catch dla bezpieczeństwa)
        $sessionId = null;
        $clientId = null;
        $gclid = null;

        try {
            $sessionData = $this->sessionManager->getSessionData((int)$order->id_cart);
            if ($sessionData) {
                $sessionId = $sessionData['ga_session_id'] ?? null;
                $clientId = $sessionData['ga_client_id'] ?? null;
                $gclid = $sessionData['gclid'] ?? null;
            }
        } catch (\Throwable $e) {
            // Ignorujemy błędy bazy
        }

        // Fallback dla Client ID
        if (!$clientId) {
            $clientId = $this->helper->getClientIdForServerSide($order);
        }

        // --- DANE ZAMÓWIENIA ---
        
        $currencyCode = 'PLN';
        if ($order->id_currency) {
            $currencyObj = new Currency((int)$order->id_currency);
            $currencyCode = $currencyObj->iso_code;
        }

        $customer = new Customer((int)$order->id_customer);
        $address = new Address((int)$order->id_address_delivery);

        // --- NOWOŚĆ: Detekcja Nowy vs Powracający ---
        // Pobieramy statystyki klienta. 'nb_orders' zawiera liczbę zamówień.
        // Jeśli ma 1 zamówienie (to bieżące), to znaczy, że jest nowy.
        $stats = $customer->getStats();
        $isNewCustomer = ((int)$stats['nb_orders'] <= 1); 

        // Dane użytkownika (Enhanced Conversions)
        $userData = [
            'sha256_email_address' => [$this->hasher->hashUserData($customer->email)],
        ];
        
        $phone = !empty($address->phone_mobile) ? $address->phone_mobile : $address->phone;
        if ($phone) {
            $hashedPhone = $this->hasher->hashPhone($phone);
            if ($hashedPhone) $userData['sha256_phone_number'] = [$hashedPhone];
        }

        // Produkty
        $products = $order->getProducts();
        $items = [];
        foreach ($products as $p) {
            $items[] = [
                'item_id' => (string)$p['product_id'],
                'item_name' => $p['product_name'],
                'price' => (float)$p['product_price_wt'],
                'quantity' => (int)$p['product_quantity']
            ];
        }

        $eventParams = [
            'transaction_id' => (string)$order->id,
            'value' => (float)$order->total_paid,
            'currency' => $currencyCode,
            'tax' => (float)($order->total_paid - $order->total_paid_tax_excl),
            'shipping' => (float)$order->total_shipping,
            'items' => $items,
            'engagement_time_msec' => 100,
            
            // --- PARAMETR BIZNESOWY ---
            'new_customer' => $isNewCustomer, // true (jeśli pierwszy zakup) lub false
        ];

        if ($sessionId) {
            $eventParams['session_id'] = (string)$sessionId;
        }

        $payload = [
            'client_id' => (string)$clientId,
            'user_id' => (string)$customer->id,
            'non_personalized_ads' => false,
            'consent' => [
                'ad_user_data' => 'GRANTED',
                'ad_personalization' => 'GRANTED',
            ],
            'events' => [
                [
                    'name' => $eventName,
                    'params' => $eventParams
                ]
            ],
            'user_data' => $userData 
        ];

        // Logowanie
        \PrestaShopLogger::addLog(
            'PsExpertTracking: Sending ' . strtoupper($eventName) . ' (NewCustomer: ' . ($isNewCustomer ? 'YES' : 'NO') . ') Order: ' . $order->id, 
            1
        );

        // Wysłanie do Google
        $this->client->sendPurchaseEvent($payload, $gclid);
    }
}