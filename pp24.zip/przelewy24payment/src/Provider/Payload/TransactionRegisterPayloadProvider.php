<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * @author    Przelewy24 powered by Waynet
 * @copyright Przelewy24
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Przelewy24\Provider\Payload;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Przelewy24\Api\Przelewy24\Dto\Body\TransactionRegister;
use Przelewy24\Calculator\AmountExtraChargeCalculator;
use Przelewy24\Configuration\Enum\OrderIdEnum;
use Przelewy24\Configuration\Enum\StatusDriverEnum;
use Przelewy24\Helper\Url\UrlHelper;
use Przelewy24\Model\Dto\Przelewy24Config;

class TransactionRegisterPayloadProvider
{
    /**
     * @var UrlHelper
     */
    private $urlHelper;

    /**
     * @var AmountExtraChargeCalculator
     */
    private $chargeCalculator;

    public function __construct(UrlHelper $urlHelper, AmountExtraChargeCalculator $chargeCalculator)
    {
        $this->urlHelper = $urlHelper;
        $this->chargeCalculator = $chargeCalculator;
    }

    public function buildPayload(int $id_payment, \Cart $cart, Przelewy24Config $config, bool $regulationsAccepted)
    {
        $customer = new \Customer($cart->id_customer);
        $address = new \Address($cart->id_address_invoice);
        $sessionID = $cart->id . '|' . hash('sha224', (string) rand());

        $transactionRegister = new TransactionRegister();
        $transactionRegister->setMerchantId((int) $config->getCredentials()->getIdMerchant());
        $transactionRegister->setPosId((int) $config->getCredentials()->getShopId());
        $transactionRegister->setSessionId($sessionID);
        $transactionRegister->setCurrency((string) $config->getAccount()->getIsoCurrency());
        $transactionRegister->setAmount(
            (int) round(($cart->getOrderTotal() + $this->chargeCalculator->getAmount($config->getExtraCharge(), $cart)) * 100));

        $idOrder = \Order::getIdByCartId($cart->id);
        $description = 'cart ' . $cart->id;
        if ($idOrder) {
            $order = new \Order($idOrder);
            $config->getOrder()->getOrderIdentification();
            $identification = $config->getOrder()->getOrderIdentification() === OrderIdEnum::ID ? $order->id : $order->reference;
            $description = 'order ' . $identification;
        }
        $transactionRegister->setDescription((string) $description);

        $transactionRegister->setEmail((string) $customer->email);
        $transactionRegister->setClient($customer->firstname . ' ' . $customer->lastname);
        $transactionRegister->setAddress($address->address1 . ' ' . $address->address2);
        $transactionRegister->setZip((string) $address->postcode);
        $transactionRegister->setCity((string) $address->city);
        $idCountry = $address->id_country ? $address->id_country : \Context::getContext()->country->id;
        $transactionRegister->setCountry(\Country::getIsoById((int) $idCountry));
        $transactionRegister->setLanguage(\Context::getContext()->language->iso_code);
        $transactionRegister->setMethod((int) $id_payment);
        $transactionRegister->setUrlReturn((string) $this->urlHelper->getUrlReturn($sessionID));
        $transactionRegister->setUrlStatus((string) $this->urlHelper->getUrlStatus(StatusDriverEnum::TRANSACTION_STATUS));
        $transactionRegister->setShipping((int) 0);
        $transactionRegister->setWaitForResult((bool) $config->getTime()->getWaitForResult());
        $transactionRegister->setTimeLimit((int) $config->getTime()->getTimeLimit());
        $transactionRegister->setRegulationAccept((bool) $regulationsAccepted);
        $transactionRegister->setEncoding('UTF-8');
        $transactionRegister->calculateSign($config->getCredentials()->getSalt());

        return $transactionRegister;
    }
}
