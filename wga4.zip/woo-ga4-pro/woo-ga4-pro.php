<?php
/**
 * Plugin Name: WooCommerce GA4 Expert Pro Ultra v6.4.4
 * Description: ARMOR EDITION: Hybrid Session Login Tracking, Anti-Duplicate AJAX, Configurator-proof.
 * Version: 6.4.4
 * Author: Senior Developer
 */

if (!defined('ABSPATH')) exit;

class WooGA4ExpertUltraV644 {

    private $opt = 'woo_ga4_pro_settings';

    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_init', [$this, 'reg_settings']);
        add_action('wp_head', [$this, 'inject_head'], 1);
        add_action('wp_body_open', [$this, 'inject_body'], 1);
        add_action('wp_footer', [$this, 'render_armor_js'], 10);

        add_filter('woocommerce_cart_item_remove_link', [$this, 'add_data_to_remove_link'], 10, 2);
        add_action('woocommerce_checkout_order_processed', [$this, 'execute_capture'], 10, 1);
        add_action('woocommerce_order_status_changed', [$this, 'schedule_ga4_events'], 10, 4);
        add_action('ga4_delayed_event_v640', [$this, 'dispatch_event_from_queue'], 10, 2);
    }

    public function reg_settings() {
        $keys = ['ga4_mid', 'ga4_api_secret', 'gtm_head', 'gtm_body', 'ga_container_id', 'debug_mode'];
        foreach ($keys as $k) register_setting($this->opt, $k);
    }

    public function add_data_to_remove_link($link, $cart_item_key) {
        $cart_item = WC()->cart->get_cart()[$cart_item_key];
        return str_replace('class="remove"', 'class="remove" data-product_id="'.$cart_item['product_id'].'" data-price="'.$cart_item['data']->get_price().'"', $link);
    }

    private function is_ga4_debug_enabled() {
        return get_option('debug_mode') === '1';
    }

    public function render_armor_js() {
        echo '<script>window.dataLayer = window.dataLayer || [];</script>';
        ?>
        <script>
        jQuery(function($) {
            // 1. SPRAWDŹ CZY WYSTĄPIŁO LOGOWANIE (Session Storage persist po przeładowaniu)
            if (sessionStorage.getItem('ga4_pending_login')) {
                dataLayer.push({
                    event: 'login',
                    method: 'password'
                });
                sessionStorage.removeItem('ga4_pending_login');
            }

            // 2. DETEKTOR LOGOWANIA (Zapisuje flagę przed przeładowaniem strony)
            $(document).on('submit', 'form.login, form#loginform, form.woocommerce-form-login', function() {
                sessionStorage.setItem('ga4_pending_login', 'true');
            });

            // A. PANCERNE VIEW_ITEM_LIST
            function scanProducts() {
                var products = [];
                $('.product').each(function(index) {
                    var $p = $(this);
                    var id = $p.find('.add_to_cart_button').data('product_id') || ($p.attr('class') && $p.attr('class').match(/post-([0-9]+)/));
                    if (id && products.length < 12) {
                        products.push({
                            item_id: String(Array.isArray(id) ? id[1] : id),
                            item_name: $p.find('.woocommerce-loop-product__title').text().trim() || $p.find('h2').text().trim(),
                            index: index
                        });
                    }
                });
                if (products.length > 0) {
                    dataLayer.push({ecommerce:null});
                    dataLayer.push({ event: 'view_item_list', ecommerce: { items: products } });
                }
            }
            if ($('.type-product, .product').length) scanProducts();

            // B. PANCERNY INTERCEPTOR Z BLOKADĄ DUPLIKATÓW
            var ga4_lock = false; 
            $(document).ajaxComplete(function(event, xhr, settings) {
                if (ga4_lock) return;
                var isAddToCart = settings.data && (typeof settings.data === 'string') && (settings.data.indexOf('add-to-cart') !== -1 || settings.data.indexOf('product_id') !== -1);
                var isWcAjax = settings.url.indexOf('add_to_cart') !== -1;

                if (isAddToCart || isWcAjax) {
                    try {
                        var params = new URLSearchParams(settings.data);
                        var productId = params.get('add-to-cart') || params.get('product_id') || params.get('variation_id');
                        if (!productId) { var $btn = $(document.activeElement); productId = $btn.data('product_id') || $btn.val(); }

                        if (productId) {
                            ga4_lock = true;
                            dataLayer.push({ecommerce:null});
                            dataLayer.push({
                                event: 'add_to_cart',
                                ecommerce: {
                                    currency: "<?php echo get_woocommerce_currency(); ?>",
                                    items: [{ item_id: String(productId), quantity: parseInt(params.get('quantity') || 1) }]
                                }
                            });
                            setTimeout(function() { ga4_lock = false; }, 800);
                        }
                    } catch (err) { console.error('GA4 Ajax Error:', err); ga4_lock = false; }
                }
            });

            // C. REMOVE, SHIPPING, PAYMENT
            $(document).on('click', 'a.remove', function() {
                var id = $(this).data('product_id');
                if(id) { dataLayer.push({ecommerce:null}); dataLayer.push({event:'remove_from_cart', ecommerce:{items:[{item_id:String(id), quantity:1}]}}); }
            });

            $(document.body).on('change', 'input[name^="shipping_method"], input[name="payment_method"]', function() {
                var name = $(this).attr('name');
                var ev = (name && name.includes('shipping')) ? 'add_shipping_info' : 'add_payment_info';
                dataLayer.push({ event: ev, ecommerce: { value: $(this).val() } });
            });

            function getC(n) { var v = document.cookie.match('(^|;) ?' + n + '=([^;]*)(;|$)'); return v ? v[2] : null; }
            $(document.body).on('init_checkout updated_checkout', function() {
                if (!$('#ga4_cid_push').length) $('form.checkout').append('<input type="hidden" name="ga4_cid_push" id="ga4_cid_push"><input type="hidden" name="ga4_sid_push" id="ga4_sid_push">');
                $('#ga4_cid_push').val(getC('_ga')); 
                $('#ga4_sid_push').val(getC('_ga_<?php echo get_option('ga_container_id'); ?>'));
            });
        });
        </script>
        <?php

        // Wyświetlanie standardowych eventów (View Item / Cart)
        if (is_product()) {
            global $product; if ($product) {
                $items = [['item_id'=>(string)$product->get_id(),'item_name'=>$product->get_name(),'price'=>(float)$product->get_price(),'quantity'=>1]];
                echo '<script>dataLayer.push({ecommerce:null});dataLayer.push({"event":"view_item","ecommerce":{"currency":"'.get_woocommerce_currency().'","value":'.(float)$product->get_price().',"items":'.json_encode($items).'}});</script>';
            }
        }
        
        if (is_cart() || (is_checkout() && !is_wc_endpoint_url('order-received'))) {
            $items = []; foreach (WC()->cart->get_cart() as $c) { $p = $c['data']; $items[] = ['item_id'=>(string)$p->get_id(),'item_name'=>$p->get_name(),'price'=>(float)$p->get_price(),'quantity'=>(int)$c['quantity']]; }
            $ev = is_cart() ? 'view_cart' : 'begin_checkout';
            echo '<script>dataLayer.push({ecommerce:null});dataLayer.push({"event":"'.$ev.'","ecommerce":{"currency":"'.get_woocommerce_currency().'","value":'.(float)WC()->cart->get_total('raw').',"items":'.json_encode($items).'}});</script>';
        }
    }

    public function execute_capture($order_id) {
        $order = wc_get_order($order_id); if (!$order) return;
        $order->update_meta_data('_ga4_cache_cid', $this->clean_id($_POST['ga4_cid_push'] ?? $_COOKIE['_ga'] ?? ''));
        $order->update_meta_data('_ga4_cache_sid', $this->clean_sid($_POST['ga4_sid_push'] ?? $_COOKIE['_ga_'.get_option('ga_container_id')] ?? ''));
        $order->save();
    }
    private function clean_id($id) { $p = explode('.', $id); return (count($p) >= 2) ? $p[count($p)-2].'.'.$p[count($p)-1] : $id; }
    private function clean_sid($sid) { if (preg_match('/t([0-9]{10})/', $sid, $m)) return $m[1]; if (preg_match('/\.([0-9]{10})/', $sid, $m)) return $m[1]; return is_numeric($sid) ? $sid : time(); }
    
    public function schedule_ga4_events($order_id, $f, $t, $o) {
        if (in_array($t, ['on-hold', 'processing', 'completed']) && !$o->get_meta('_ga4_done')) {
            wp_schedule_single_event(time() + 5, 'ga4_delayed_event_v640', [$order_id, 'purchase']);
        }
    }

    public function dispatch_event_from_queue($order_id, $event_name) {
        $order = wc_get_order($order_id); if (!$order) return;
        $payload = [
            'client_id' => $order->get_meta('_ga4_cache_cid') ?: (string)time(),
            'events' => [[
                'name' => $event_name, 
                'params' => [
                    'transaction_id' => (string)$order->get_order_number(), 
                    'value' => (float)$order->get_total(), 
                    'currency' => $order->get_currency(), 
                    'session_id' => (string)$order->get_meta('_ga4_cache_sid'), 
                    'debug_mode' => $this->is_ga4_debug_enabled() ? 1 : null, 
                    'items' => $this->get_items($order)
                ]
            ]]
        ];
        wp_remote_post("https://www.google-analytics.com/mp/collect?measurement_id=".get_option('ga4_mid')."&api_secret=".get_option('ga4_api_secret'), [
            'body' => wp_json_encode($payload),
            'blocking' => false
        ]);
        $order->update_meta_data('_ga4_done', time()); 
        $order->save();
    }

    private function get_items($order) { 
        $items = []; 
        foreach ($order->get_items() as $item) { 
            $items[] = ['item_id' => (string)$item->get_product_id(), 'item_name' => $item->get_name(), 'quantity' => (int)$item->get_quantity(), 'price' => (float)$order->get_item_total($item)]; 
        } 
        return $items; 
    }

    public function inject_head() { echo get_option('gtm_head'); }
    public function inject_body() { echo get_option('gtm_body'); }
    public function add_menu() { add_options_page('GA4 Expert Pro', 'GA4 Expert Pro', 'manage_options', 'woo-ga4-pro', [$this, 'render_html']); }
    
    public function render_html() { ?>
        <div class="wrap">
            <h1>GA4 Expert Pro v6.4.4</h1>
            <form method="post" action="options.php">
                <?php settings_fields($this->opt); ?>
                <table class="form-table">
                    <tr><th>GA4 Mid</th><td><input type="text" name="ga4_mid" value="<?php echo esc_attr(get_option('ga4_mid')); ?>" /></td></tr>
                    <tr><th>API Secret</th><td><input type="text" name="ga4_api_secret" value="<?php echo esc_attr(get_option('ga4_api_secret')); ?>" /></td></tr>
                    <tr><th>Cookie Container ID</th><td><input type="text" name="ga_container_id" value="<?php echo esc_attr(get_option('ga_container_id')); ?>" /></td></tr>
                    <tr><th>GTM Code (Head)</th><td><textarea name="gtm_head" rows="5" class="large-text"><?php echo esc_textarea(get_option('gtm_head')); ?></textarea></td></tr>
                    <tr><th>GTM Code (Body)</th><td><textarea name="gtm_body" rows="2" class="large-text"><?php echo esc_textarea(get_option('gtm_body')); ?></textarea></td></tr>
                    <tr><th>Debug Mode</th><td><input type="checkbox" name="debug_mode" value="1" <?php checked(1, get_option('debug_mode')); ?> /> Włącz DebugView</td></tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
    <?php }
}
new WooGA4ExpertUltraV644();