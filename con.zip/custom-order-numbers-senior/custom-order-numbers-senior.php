<?php
/**
 * Plugin Name: Custom Order Numbers (Bulletproof Edition)
 * Description: Wersja 7.0.0 - Posiada mechanizm "Auto-Skip". Jeśli ręcznie cofniesz licznik na zajęty numer, wtyczka automatycznie znajdzie pierwszy wolny i naprawi licznik.
 * Version: 7.0.0
 * Author: Senior WooCommerce Developer
 * Text Domain: custom-order-numbers-bulletproof
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'plugins_loaded', 'alg_wc_bulletproof_init' );

function alg_wc_bulletproof_init() {
	if ( ! class_exists( 'WooCommerce' ) ) return;
	
	Alg_WC_Custom_Order_Numbers_Bulletproof::instance();
	add_filter( 'woocommerce_get_settings_pages', 'alg_wc_add_bulletproof_settings_page' );
}

/**
 * USTAWIENIA (Interfejs Admina)
 */
function alg_wc_add_bulletproof_settings_page( $settings ) {
	if ( ! class_exists( 'WC_Settings_Page' ) ) return $settings;

	if ( ! class_exists( 'Alg_WC_Settings_Bulletproof' ) ) {
		class Alg_WC_Settings_Bulletproof extends WC_Settings_Page {

			public function __construct() {
				$this->id    = 'alg_wc_custom_order_numbers';
				$this->label = __( 'Custom Order Numbers', 'custom-order-numbers-bulletproof' );
				parent::__construct();
				add_action( 'admin_print_footer_scripts', array( $this, 'output_live_preview_script' ) );
			}

			public function get_settings() {
				$counter  = get_option( 'alg_wc_custom_order_numbers_counter', 1 );
				$width    = get_option( 'alg_wc_custom_order_numbers_width', 2 );
				$template = get_option( 'alg_wc_custom_order_numbers_template', '{ymd}{number}' );
				
				$settings = array(
					array( 'title' => __( 'Konfiguracja Numeracji', 'custom-order-numbers-bulletproof' ), 'type' => 'title', 'id' => 'alg_wc_options' ),

					array(
						'title'    => __( 'Szablon (Template)', 'custom-order-numbers-bulletproof' ),
						'desc'     => 'Tagi: <code>{number}</code>, <code>{Ymd}</code>, <code>{Y-m-d}</code>, <code>{order_id}</code>.',
						'id'       => 'alg_wc_custom_order_numbers_template',
						'default'  => '{ymd}{number}',
						'type'     => 'text',
						'css'      => 'min-width:300px;',
					),
					array(
						'title' => __( 'Podgląd 1: Zamówienie DZISIAJ', 'custom-order-numbers-bulletproof' ),
						'desc'  => '<div id="alg_live_preview_today" style="font-family:monospace; background:#dff0d8; color:#3c763d; padding:8px 15px; font-size:16px; font-weight:bold; border:1px solid #d6e9c6; display:inline-block;">...</div>',
						'type'  => 'title',
						'id'    => 'alg_wc_preview_today_field',
					),
					array(
						'title' => __( 'Podgląd 2: Następny Cykl / Reset', 'custom-order-numbers-bulletproof' ),
						'desc'  => '<div id="alg_live_preview_tomorrow" style="font-family:monospace; background:#d9edf7; color:#31708f; padding:8px 15px; font-size:16px; font-weight:bold; border:1px solid #bce8f1; display:inline-block;">...</div>',
						'type'  => 'title',
						'id'    => 'alg_wc_preview_tomorrow_field',
					),
					array(
						'title'    => __( 'Następny Numer (Licznik)', 'custom-order-numbers-bulletproof' ),
						'desc'     => 'To jest sam numer porządkowy (np. 1, 5, 100). Nie wpisuj tu pełnego numeru z datą!',
						'id'       => 'alg_wc_custom_order_numbers_counter',
						'default'  => 1,
						'type'     => 'number',
						'custom_attributes' => array( 'min' => 1 ),
					),
					array(
						'title'    => __( 'Minimalna długość (Width)', 'custom-order-numbers-bulletproof' ),
						'id'       => 'alg_wc_custom_order_numbers_width',
						'default'  => 2,
						'type'     => 'number',
					),
					array(
						'title'    => __( 'Resetowanie', 'custom-order-numbers-bulletproof' ),
						'id'       => 'alg_wc_custom_order_numbers_counter_reset_enabled',
						'default'  => 'daily',
						'type'     => 'select',
						'options'  => array(
							'disabled' => 'Brak resetu',
							'daily'    => 'Codziennie',
							'monthly'  => 'Miesięcznie',
							'yearly'   => 'Rocznie',
						),
					),
					array( 'type' => 'sectionend', 'id' => 'alg_wc_options' ),
				);
				return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings );
			}

			public function output_live_preview_script() {
				if ( ! isset( $_GET['tab'] ) || 'alg_wc_custom_order_numbers' !== $_GET['tab'] ) return;
				?>
				<script type="text/javascript">
				jQuery(document).ready(function($){
					var $inTpl = $('#alg_wc_custom_order_numbers_template'), $inCnt = $('#alg_wc_custom_order_numbers_counter');
					var $inWdt = $('#alg_wc_custom_order_numbers_width'), $inRst = $('#alg_wc_custom_order_numbers_counter_reset_enabled');
					var $outToday = $('#alg_live_preview_today'), $outTmrw  = $('#alg_live_preview_tomorrow');

					function formatDate(d,f){
						var Y=d.getFullYear(),y=Y.toString().slice(-2),m=("0"+(d.getMonth()+1)).slice(-2),D=("0"+d.getDate()).slice(-2);
						return f.replace(/Y/g,Y).replace(/y/g,y).replace(/m/g,m).replace(/d/g,D);
					}
					function pad(n,s){var S=n.toString();while(S.length<s)S="0"+S;return S;}
					function parse(t,c,w,d){
						return t.replace('{number}',pad(c,w)).replace('{order_id}','1234').replace(/\{([^{}]+)\}/g,function(m,cc){
							return (cc==='number'||cc==='order_id')?m:formatDate(d,cc);
						});
					}
					function upd(){
						var t=$inTpl.val(), c=parseInt($inCnt.val())||1, w=parseInt($inWdt.val())||1, r=$inRst.val();
						var now=new Date(), tmrw=new Date(now);
						
						$outToday.text(parse(t,c,w,now));

						var tc=c; 
						if(r==='monthly'){ tmrw.setMonth(tmrw.getMonth()+1); tmrw.setDate(1); tc=1; }
						else if(r==='yearly'){ tmrw.setFullYear(tmrw.getFullYear()+1); tmrw.setMonth(0); tmrw.setDate(1); tc=1; }
						else if(r==='daily'){ tmrw.setDate(tmrw.getDate()+1); tc=1; }
						else { tmrw.setDate(tmrw.getDate()+1); tc=c+1; }
						
						$outTmrw.text(parse(t,tc,w,tmrw));
					}
					$inTpl.add($inCnt).add($inWdt).add($inRst).on('input keyup change',upd);
					upd();
				});
				</script>
				<?php
			}
		}
	}
	$settings[] = new Alg_WC_Settings_Bulletproof();
	return $settings;
}

/**
 * GŁÓWNA LOGIKA (Core) - Z SAMOLECZENIEM DUPLIKATÓW
 */
class Alg_WC_Custom_Order_Numbers_Bulletproof {

	private static $instance;
	private $meta_key_formatted = '_alg_wc_full_custom_order_number'; 
	private $meta_key_counter   = '_alg_wc_custom_order_number';
	private $option_counter     = 'alg_wc_custom_order_numbers_counter';
	private $option_last_reset  = 'alg_wc_custom_order_numbers_counter_previous_order_date';

	public static function instance() {
		if ( is_null( self::$instance ) ) self::$instance = new self();
		return self::$instance;
	}

	public function __construct() {
		add_action( 'woocommerce_new_order', array( $this, 'generate_number_safe' ), 10, 2 ); // Zmieniona nazwa
		add_filter( 'woocommerce_order_number', array( $this, 'display_number' ), 10, 2 );
		
		add_action( 'add_meta_boxes', array( $this, 'add_mb' ) );
		add_action( 'woocommerce_process_shop_order_meta', array( $this, 'save_mb_validated' ) );
		add_action( 'admin_notices', array( $this, 'show_validation_errors' ) );

		add_filter( 'woocommerce_shop_order_search_fields', array( $this, 'search_f' ) );
		add_filter( 'woocommerce_order_table_search_query_meta_keys', array( $this, 'search_f' ) );
		
		add_filter( 'woocommerce_rest_shop_order_object_query', array( $this, 'enable_api_search_by_custom_number' ), 10, 2 );
	}

	/**
	 * GENERAOWANIE Z PĘTLĄ BEZPIECZEŃSTWA (Auto-Skip)
	 */
	public function generate_number_safe( $id, $order ) {
		if ( 'auto-draft' === $order->get_status() ) return;
		if ( $order->get_meta( $this->meta_key_formatted ) ) return;

		global $wpdb;
		$wpdb->query( 'START TRANSACTION' );

		try {
			// 1. Pobierz licznik z blokadą
			$counter = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->prefix}options WHERE option_name = %s FOR UPDATE", $this->option_counter ) );
			if ( ! $counter ) $counter = (int) get_option( $this->option_counter, 1 );

			// 2. Obsługa resetu (Data)
			$reset = get_option( 'alg_wc_custom_order_numbers_counter_reset_enabled', 'daily' );
			$counter = $this->check_reset( $counter, $reset );

			$tpl = get_option( 'alg_wc_custom_order_numbers_template', '{ymd}{number}' );
			$wid = get_option( 'alg_wc_custom_order_numbers_width', 2 );

			// 3. PĘTLA BEZPIECZEŃSTWA (NOWOŚĆ)
			// Jeśli wygenerowany numer jest zajęty, zwiększaj licznik aż znajdziesz wolny.
			$final = '';
			$safety_limit = 100; // Zabezpieczenie przed nieskończoną pętlą
			$found_unique = false;

			while ( ! $found_unique && $safety_limit > 0 ) {
				// Formatuj potencjalny numer
				$final = $this->format( $tpl, $counter, $wid, $order );

				// Sprawdź w bazie czy istnieje (ignorując to konkretne zamówienie ID, które właśnie tworzymy)
				$exists = $wpdb->get_var( $wpdb->prepare( 
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s AND post_id != %d LIMIT 1", 
					$this->meta_key_formatted, 
					$final,
					$id
				) );

				if ( $exists ) {
					// ZAJĘTE! Ktoś cofnął licznik. Przeskakujemy.
					$counter++; 
					$safety_limit--;
				} else {
					// WOLNE!
					$found_unique = true;
				}
			}

			// 4. Zapisz
			$order->update_meta_data( $this->meta_key_formatted, $final );
			$order->update_meta_data( $this->meta_key_counter, $counter );
			$order->save();

			// 5. Zaktualizuj licznik globalny na kolejny wolny (+1)
			update_option( $this->option_counter, $counter + 1 );
			$wpdb->query( 'COMMIT' );

		} catch ( Exception $e ) { $wpdb->query( 'ROLLBACK' ); }
	}

	private function check_reset( $cnt, $mode ) {
		if ( in_array( $mode, ['disabled','no'] ) ) return $cnt;
		$last = get_option( $this->option_last_reset, 0 );
		$now = current_time( 'timestamp' );
		$do = false;
		if ( ! $last ) { update_option( $this->option_last_reset, $now ); return $cnt; }
		if ( 'daily' === $mode && date('Ymd',$now) != date('Ymd',$last) ) $do = true;
		if ( 'monthly' === $mode && date('Ym',$now) != date('Ym',$last) ) $do = true;
		if ( 'yearly' === $mode && date('Y',$now) != date('Y',$last) ) $do = true;
		if ( $do ) { update_option( $this->option_last_reset, $now ); return 1; }
		return $cnt;
	}

	private function format( $tpl, $cnt, $wid, $ord ) {
		$s = sprintf( '%0'.$wid.'d', $cnt );
		$o = str_replace( '{number}', $s, $tpl );
		$o = str_replace( '{order_id}', $ord->get_id(), $o );
		return preg_replace_callback( '/\{([^{}]+)\}/', function($m){
			return date( $m[1], current_time('timestamp') );
		}, $o );
	}

	public function display_number( $num, $ord ) {
		$c = $ord->get_meta( $this->meta_key_formatted );
		return $c ? $c : $num;
	}

	public function add_mb() {
		$scr = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ? wc_get_page_screen_id('shop-order') : 'shop_order';
		add_meta_box( 'alg_wc_mb', 'Order Number', array($this,'render_mb'), $scr, 'side', 'high' );
	}

	public function render_mb( $p ) {
		$o = ($p instanceof WP_Post) ? wc_get_order($p->ID) : $p;
		wp_nonce_field( 'alg_s', 'alg_n' );
		echo '<input type="text" name="alg_i" value="'.esc_attr($o->get_meta($this->meta_key_formatted)).'" style="width:100%">';
		echo '<p class="description" style="margin-top:5px; color:#666;">System waliduje unikalność. Zmiana nadpisuje automat.</p>';
	}

	public function save_mb_validated( $id ) {
		if ( ! isset($_POST['alg_n']) || ! wp_verify_nonce($_POST['alg_n'], 'alg_s') ) return;
		$o = wc_get_order($id);
		if ( isset($_POST['alg_i']) ) { 
			$nv = sanitize_text_field( $_POST['alg_i'] );
			$cv = $o->get_meta( $this->meta_key_formatted );
			if ( $nv === $cv ) return;

			if ( ! empty( $nv ) ) {
				global $wpdb;
				$dup = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s AND post_id != %d LIMIT 1", $this->meta_key_formatted, $nv, $id ) );
				if ( $dup ) {
					set_transient( 'alg_wc_err_'.get_current_user_id(), "BŁĄD: Numer <strong>$nv</strong> jest zajęty przez zamówienie #$dup!", 45 );
					return; 
				}
				$o->update_meta_data($this->meta_key_formatted, $nv);
				$o->save();
			} else {
				$o->delete_meta_data($this->meta_key_formatted);
				$o->save();
			}
		}
	}

	public function show_validation_errors() {
		$tr = 'alg_wc_err_' . get_current_user_id();
		if ( $e = get_transient( $tr ) ) {
			echo '<div class="notice notice-error is-dismissible"><p>'.$e.'</p></div>';
			delete_transient( $tr );
		}
	}

	public function search_f( $f ) { $f[] = $this->meta_key_formatted; return $f; }

	public function enable_api_search_by_custom_number( $args, $request ) {
		if ( ! empty( $request->get_param( 'search' ) ) ) {
			$args['meta_query'] = isset($args['meta_query']) ? $args['meta_query'] : [];
			$args['meta_query'][] = array( 'key' => $this->meta_key_formatted, 'value' => $request->get_param( 'search' ), 'compare' => 'LIKE' );
		}
		return $args;
	}
}