<?php return array('dependencies' => array('react-jsx-runtime'), 'version' => '6194fedae22ecbeeecb2');
