<?php return array('dependencies' => array('react-jsx-runtime'), 'version' => 'd7b2ae8848bdcfe9207f');
