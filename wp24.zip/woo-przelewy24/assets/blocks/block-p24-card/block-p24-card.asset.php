<?php return array('dependencies' => array('react', 'react-jsx-runtime', 'wp-blocks-checkout', 'wp-html-entities', 'wp-i18n'), 'version' => 'b4e2f7bd6959faf5d84e');
