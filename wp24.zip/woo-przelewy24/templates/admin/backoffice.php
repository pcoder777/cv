<?php
/**
 * @var string $banner
 * @var string $url
 */
?>

<div class="notice p24-backoffice">
    <a href="<?= $url ?>" target="_blank">
        <img src="<?= $banner ?>" alt="" />
    </a>
</div>
