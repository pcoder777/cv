<div id="p24-payment-status">
    <h4><?php _e('We are verifying your payment status', 'woocommerce-p24'); ?></h4>
    <p id="p24-processing-msg"><?php _e('Your payment is being processed. Please do not close this page.', 'woocommerce-p24'); ?></p>
    <p id="p24-wait-msg"><?php _e('Please wait...', 'woocommerce-p24'); ?></p>
    <div class="p24-loader"></div>
    <div id="p24-status-message"></div>
</div>
